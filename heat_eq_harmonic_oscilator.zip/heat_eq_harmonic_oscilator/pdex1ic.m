function u0 = pdex1ic(x,freq)
u0 = sin(freq*pi*x);